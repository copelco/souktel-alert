#!/usr/bin/env python
# vim: ai ts=4 sts=4 et sw=4

PROJECT_NAME = "RapidSMS"
PAGINATOR_OBJECTS_PER_PAGE = 12
PAGINATOR_MAX_PAGE_LINKS = 5
