#!/usr/bin/env python
# vim: ai ts=4 sts=4 et sw=4

AJAX_PROXY_HOST = "localhost"
AJAX_PROXY_PORT = 8001
